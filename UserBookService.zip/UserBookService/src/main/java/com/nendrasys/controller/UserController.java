package com.nendrasys.controller;
import com.nendrasys.dao.UserDao;
import com.nendrasys.model.UserRegistrationModel;
import com.nendrasys.service.UserService;
import com.nendrasys.validations.UserRegistrationValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/")
public class UserController {
    @Autowired
    UserService userService;
    @Autowired
    UserDao userDao;

    @Autowired
    UserRegistrationValidation userRegistrationValidation;

    /***
     * for validating the registration form data
     * @param binder
     */
    @InitBinder
    protected void initBinder(WebDataBinder binder) {
        binder.addValidators(userRegistrationValidation);
    }

    /***
     * getting registration form
     * @param model
     * @return
     */
    @RequestMapping(value = "/userRegForm",method = RequestMethod.GET)
    public String getUserRegisterForm(Model model){
        UserRegistrationModel userRegistrationModel = new UserRegistrationModel();
        model.addAttribute("user", userRegistrationModel);
        return "userRegistrationForm";
    }

    /***
     * Binding result contains the result of validations
     * @param registrationModel
     * @param result
     * @param model
     * @return
     */
    @RequestMapping(value = "/userRegistration",method = RequestMethod.POST)
    public String registerUser(@ModelAttribute("user") @Validated UserRegistrationModel registrationModel, BindingResult result,
                               Model model){
        int emailCount = userDao.getEmail(registrationModel);
        if(emailCount==1){
            result.rejectValue("email","userRegistrationModel.email.exist");
        }
        if(result.hasErrors()){
            return "userRegistrationForm";
        }
        String resultMsg = null;
        resultMsg = userService.saveUserRegData(registrationModel);
        model.addAttribute("result",resultMsg);
        return "registrationSuccess";
    }

    /***
     * for applying constant data to the application ex:country of the user
     * @return
     */
    @ModelAttribute("country")
    public List<String> countryList() {
        List<String> countries = new ArrayList<String>();
        countries.add("India");
        countries.add("US");
        return countries;
    }

    /***
     * country code
     * @return
     */
    @ModelAttribute("countryCode")
    public List<String> countryCodes() {
        List<String> codes = new ArrayList<String>();
        codes.add("+91");
        codes.add("+1");
        return codes;
    }

}
