package com.nendrasys.controller;

import com.nendrasys.model.BookModel;
import com.nendrasys.model.BookModelList;
import com.nendrasys.model.UserRegistrationModel;
import com.nendrasys.service.BookRestService;
import com.nendrasys.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;
import java.util.Currency;
import java.util.Locale;

@Controller
@RequestMapping("/")
public class BookDataController {
    @Autowired
    BookRestService bookRestService;
    @Autowired
    UserService userService;

    /***
     *  getting book information in xml format from server
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/getAllBooksXmlRest",produces = {"application/xml"})
    public BookModelList restCallToBookInfoXml(){
        return bookRestService.getAllBookInfoXml();
    }

    /***
     * for getting book data by id in xml format from server
     * @param model
     * @param bookId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/getBookByIdXmlRest/{bookId}",produces = {"application/xml"})
    public BookModel getBookById(Model model, @PathVariable(value = "bookId") int bookId){
        return bookRestService.getBookByIdXml(bookId);
    }

    /***
     * for getting book details in object format and differentiate before and after login
     * @param model
     * @param principal
     * @return
     */
    @RequestMapping(value = "/getAllBooksData")
    public String restCallToBookInfoUsObj(Model model,Principal principal){
        Authentication authentication =  SecurityContextHolder.getContext().getAuthentication();
        if (!(authentication instanceof AnonymousAuthenticationToken)){
        UserRegistrationModel registrationModel=userService.getUserdetails(principal);
        if(registrationModel.getCountry().equals("India")){
            BookModelList bookModelList1 = bookRestService.getAllBookInfoXml();
            model.addAttribute("booksData",bookModelList1);
            return "bookInrPriceObjData";
        }else {
            BookModelList bookModelList2 = bookRestService.getAllBookInfoXml();
            model.addAttribute("booksData",bookModelList2);
            return "bookUsPriceObjData";
        }
        }
        else {
            BookModelList bookModelList3 = bookRestService.getAllBookInfoXml();
            model.addAttribute("booksData",bookModelList3);
            return "bookObjData";
            }
    }

    /***
     * get authentication user data
     * @param model
     * @return
     */
    @RequestMapping("/data")
    public String index(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!(auth instanceof AnonymousAuthenticationToken))
            return "bookObjData";
        // if it is not authenticated, then go to the index...
        // other things ...
        return "error";
    }

    /***
     * getting after login user details
     * @param principal
     * @param locale
     * @return
     */
    @RequestMapping("/getUserDetails")
    @ResponseBody
    public UserRegistrationModel getUserDetails(Principal principal , Locale locale){
        UserRegistrationModel registrationModel=userService.getUserdetails(principal);
        System.out.println(registrationModel.getCountry());
        System.out.println(registrationModel);
        return registrationModel;
    }

    /***
     * get book details by id with india price from sever
     * @param model
     * @param bookId
     * @return
     */
    @RequestMapping(value = "/getBookByIdObjIn/{bookId}")
    public ModelAndView getInBookByIdObj(Model model, @PathVariable(value = "bookId") int bookId){
        ModelAndView modelAndView = new ModelAndView();
        Locale indLocale = new Locale("hi", "IN");
        Currency currency = Currency.getInstance(indLocale);
        String inrCode = currency.getCurrencyCode();
        BookModel bookModel = bookRestService.getBookByIdXml(bookId);
        modelAndView.addObject("bookRes",bookModel);
        model.addAttribute("priceCode",inrCode);
        System.out.println(bookModel);
        modelAndView.setViewName("inBookDataById");
        return modelAndView;
    }

    /***
     * get book by id with us price from server
     * @param model
     * @param bookId
     * @return
     */
    @RequestMapping(value = "/getBookByIdObjUs/{bookId}")
    public ModelAndView getUsBookByIdObj(Model model, @PathVariable(value = "bookId") int bookId){
        ModelAndView modelAndView = new ModelAndView();
        Locale usdLocale = Locale.US;
        Currency currency = Currency.getInstance(usdLocale);
        String usCode =currency.getSymbol();
        BookModel bookModel = bookRestService.getBookByIdXml(bookId);
        modelAndView.addObject("bookRes",bookModel);
        model.addAttribute("priceCode",usCode);
        System.out.println(bookModel);
        modelAndView.setViewName("usBookDataById");
        return modelAndView;
    }
}
