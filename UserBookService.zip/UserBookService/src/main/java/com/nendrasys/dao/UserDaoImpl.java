package com.nendrasys.dao;


import com.nendrasys.model.BookModel;
import com.nendrasys.model.UserLoginModel;
import com.nendrasys.model.UserRegistrationModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.security.Principal;

public class UserDaoImpl implements UserDao {
    @Autowired
    private JdbcTemplate template;

    @Override
    public int saveUserRegData(UserRegistrationModel registrationModel) {
        String role = "USER";
        int enabled = 1;
        String contactNumber= registrationModel.getCountryCode()+" "+registrationModel.getContactNumber();
        String query = "insert into userregistrationinfo(name,lastName,email,password,country,contactNumber,role,enabled) values('"+registrationModel.getName()+"'" +
                ",'"+registrationModel.getLastName()+"','"+registrationModel.getEmail()+"','"+registrationModel.getPassword()+"'," +
                "'"+registrationModel.getCountry()+"','"+contactNumber+"','"+role+"','"+enabled+"')";
        return template.update(query);
    }

    @Override
    public UserRegistrationModel getRegistredDetails(Principal principal){
        String QUERY1="select * from userregistrationinfo where email='"+principal.getName()+"'";
        UserRegistrationModel userInfo = (UserRegistrationModel) template.queryForObject(QUERY1, new BeanPropertyRowMapper(UserRegistrationModel.class));
        return userInfo;
    }

    @Override
    public int getEmail(UserRegistrationModel registrationModel) {
        String query = "select count(*) from userregistrationinfo where email='"+registrationModel.getEmail()+"'";
        int count = template.queryForObject(query,Integer.class);
        if(count>0){
            return count;
        }
        return 0;
    }
}
