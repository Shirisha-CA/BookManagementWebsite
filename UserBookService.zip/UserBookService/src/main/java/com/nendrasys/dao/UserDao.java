package com.nendrasys.dao;

import com.nendrasys.model.UserLoginModel;
import com.nendrasys.model.UserRegistrationModel;

import javax.validation.constraints.Email;
import java.security.Principal;
import java.util.List;

public interface UserDao {
    public int saveUserRegData(UserRegistrationModel registrationModel);
    public UserRegistrationModel getRegistredDetails(Principal principal);
    public int getEmail(UserRegistrationModel registrationModel);
}

