package com.nendrasys.service;

import com.nendrasys.dao.UserDao;
import com.nendrasys.model.UserLoginModel;
import com.nendrasys.model.UserRegistrationModel;
import org.springframework.beans.factory.annotation.Autowired;

import java.security.Principal;

public class UserServiceImpl implements UserService {
    @Autowired
    UserDao userDao;
    @Override
    public String saveUserRegData(UserRegistrationModel registrationModel) {
        int count=0;
        count=userDao.saveUserRegData(registrationModel);
        if(count==1){
            return "Registration successfully done";
        }
        else{
            return "Registration is not done";
        }
    }
    @Override
    public UserRegistrationModel getUserdetails(Principal principal)
    {
        return userDao.getRegistredDetails(principal);
    }
}
