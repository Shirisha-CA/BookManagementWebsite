package com.nendrasys.service;

import com.nendrasys.model.UserLoginModel;
import com.nendrasys.model.UserRegistrationModel;

import java.security.Principal;

public interface UserService {
    public String saveUserRegData(UserRegistrationModel registrationModel);
    public UserRegistrationModel getUserdetails(Principal principal);
}
