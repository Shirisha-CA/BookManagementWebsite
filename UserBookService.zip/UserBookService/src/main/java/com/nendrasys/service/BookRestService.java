package com.nendrasys.service;

import com.nendrasys.model.BookModel;
import com.nendrasys.model.BookModelList;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import java.util.Arrays;

public class BookRestService {
    RestTemplate restTemplate;

    public RestTemplate getRestTemplate() {
        return restTemplate;
    }

    public void setRestTemplate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    /***
     * rest call to the server for getting book information
     * @return
     */
    public BookModelList getAllBookInfoXml() {
        BookModel bookModel = new BookModel();
        String url = "http://localhost:8976/OnlineBookSellingSystem_war_exploded/displayAllBooksJson";
        ResponseEntity<BookModel[]> obj = restTemplate.getForEntity(url, BookModel[].class);
        /*System.out.println(obj);
        System.out.println(obj.getStatusCode());*/
        System.out.println(obj.getStatusCode().value());
        BookModelList bookModelList = new BookModelList();
        bookModelList.setBookModelList(Arrays.asList(obj.getBody()));
        System.out.println(bookModelList.getBookModelList().toString());
        return bookModelList;
    }

    /***
     * rest call to the server for getting book information by id
     * @param bookId
     * @return
     */
    public BookModel getBookByIdXml(int bookId)
    {
        final String uri = "http://localhost:8976/OnlineBookSellingSystem_war_exploded/getBookByIdXmlFormat/{bookId}";
        RestTemplate restTemplate = new RestTemplate();
        BookModel result = restTemplate.getForObject(uri, BookModel.class,bookId);
        return result;
    }
}
