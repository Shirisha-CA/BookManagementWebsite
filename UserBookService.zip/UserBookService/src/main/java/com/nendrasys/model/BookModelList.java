package com.nendrasys.model;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
@XmlRootElement
public class BookModelList {
    private List<BookModel> bookModelList;

    public List<BookModel> getBookModelList() {
        return bookModelList;
    }

    public void setBookModelList(List<BookModel> bookModelList) {
        this.bookModelList = bookModelList;
    }
}

