package com.nendrasys.validations;

import com.nendrasys.model.UserRegistrationModel;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserRegistrationValidation implements Validator {
    @Override
    public boolean supports(Class<?> aClass) {
        return UserRegistrationModel.class.equals(aClass);
    }

    @Override
    public void validate(Object obj, Errors errors) {
        ValidationUtils.rejectIfEmpty(errors, "name", "userRegistrationModel.name.empty");
        ValidationUtils.rejectIfEmpty(errors, "lastName", "userRegistration.lastName.empty");
        ValidationUtils.rejectIfEmpty(errors, "email", "userRegistrationModel.email.empty");
        ValidationUtils.rejectIfEmpty(errors, "password", "userRegistrationModel.password.empty");
        ValidationUtils.rejectIfEmpty(errors, "reenterPassword", "userRegistrationModel.reenterPassword.empty");
        ValidationUtils.rejectIfEmpty(errors, "country", "userRegistrationModel.country.empty");
        ValidationUtils.rejectIfEmpty(errors, "contactNumber", "userRegistrationModel.contactNumber.empty");

        UserRegistrationModel registrationModel = (UserRegistrationModel) obj;

        //email pattern validation
        Pattern pattern = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
                Pattern.CASE_INSENSITIVE);
        if (!(pattern.matcher(registrationModel.getEmail()).matches())) {
            errors.rejectValue("email", "userRegistrationModel.email.invalid");
        }

        //password validation
        if ((registrationModel.getReenterPassword()!="")&&(!registrationModel.getPassword().equals(registrationModel.getReenterPassword()))) {
            errors.rejectValue("reenterPassword", "userRegistrationModel.reenterPassword.invalid");
        }

        //check length of password
        if ( (registrationModel.getPassword()!="")&& (registrationModel.getPassword().length() <= 8 || registrationModel.getPassword().length() > 15)) {
            errors.rejectValue("password", "userRegistrationModel.password.length");
        }

        //check mobile number size
        if ( (registrationModel.getContactNumber()!="")&& (registrationModel.getContactNumber().length() <10 || registrationModel.getContactNumber().length() > 10)) {
            errors.rejectValue("contactNumber", "userRegistrationModel.contactNumber.length");
        }

        //check phone number is in numbers or not
        String contactNumber = registrationModel.getContactNumber();
        Pattern p1=Pattern.compile("^[0-9]+$");
        Matcher m1=p1.matcher(contactNumber);
        if (m1.matches()) {
            System.out.println("Valid number");
        }else {
            errors.rejectValue("contactNumber","userRegistrationModel.contactNumber");
        }

        //check length of name
        if(registrationModel.getName().length()>30){
            errors.rejectValue("name","userRegistrationModel.name.length");
        }

        //check length of last name
        if(registrationModel.getLastName().length()>30){
            errors.rejectValue("lastName","userRegistrationModel.lastName.length");
        }
    }
}
